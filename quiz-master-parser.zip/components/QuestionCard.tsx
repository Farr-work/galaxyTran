import React, { useState } from 'react';
import { Check, X, RefreshCcw } from 'lucide-react';
import { Question } from '../types';

interface QuestionCardProps {
  question: Question;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({ question }) => {
  const [selectedOptions, setSelectedOptions] = useState<Set<string>>(new Set());
  const [isChecked, setIsChecked] = useState(false);

  const toggleOption = (optionId: string) => {
    if (isChecked) return; // Disable changing answers after checking

    const newSelected = new Set(selectedOptions);
    if (newSelected.has(optionId)) {
      newSelected.delete(optionId);
    } else {
      newSelected.add(optionId);
    }
    setSelectedOptions(newSelected);
  };

  const resetQuestion = () => {
    setSelectedOptions(new Set());
    setIsChecked(false);
  };

  const handleCheck = () => {
    if (selectedOptions.size === 0) return;
    setIsChecked(true);
  };

  // Styling helpers
  const getOptionStyles = (optionId: string, isCorrect: boolean) => {
    const isSelected = selectedOptions.has(optionId);
    
    if (!isChecked) {
      // Default state styling
      return isSelected 
        ? "bg-blue-50 border-blue-500 shadow-sm" 
        : "bg-white border-gray-200 hover:bg-gray-50";
    }

    // Checked state styling
    if (isCorrect) {
      if (isSelected) {
        // Correctly selected
        return "bg-green-100 border-green-500 ring-1 ring-green-500";
      } else {
        // Correct but missed
        return "bg-white border-green-400 border-dashed ring-1 ring-green-200 opacity-75";
      }
    } else {
      if (isSelected) {
        // Incorrectly selected
        return "bg-red-100 border-red-500";
      } else {
        // Incorrect and not selected (Standard)
        return "bg-gray-50 border-gray-200 opacity-50";
      }
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6 transition-all duration-300">
      {/* Header */}
      <div className="bg-gray-50 px-6 py-4 border-b border-gray-100">
        <h3 className="font-semibold text-gray-800 text-lg leading-relaxed">
          {question.text}
        </h3>
      </div>

      {/* Options List */}
      <div className="p-6 space-y-3">
        {question.options.map((option) => {
          const isSelected = selectedOptions.has(option.id);
          
          return (
            <div
              key={option.id}
              onClick={() => toggleOption(option.id)}
              className={`
                relative group flex items-start p-4 rounded-lg border-2 cursor-pointer transition-all duration-200
                ${getOptionStyles(option.id, option.isCorrect)}
              `}
            >
              {/* Checkbox UI */}
              <div className={`
                flex-shrink-0 mt-0.5 w-6 h-6 rounded border flex items-center justify-center mr-4 transition-colors
                ${
                  isSelected 
                    ? (isChecked && !option.isCorrect ? "bg-red-500 border-red-500" : (isChecked && option.isCorrect ? "bg-green-500 border-green-500" : "bg-blue-500 border-blue-500"))
                    : "border-gray-300 bg-white"
                }
              `}>
                {isSelected && <Check size={16} className="text-white" strokeWidth={3} />}
              </div>

              <div className="flex-1">
                <span className={`font-semibold mr-2 ${isChecked && option.isCorrect && !isSelected ? "text-green-600" : "text-gray-900"}`}>
                  {option.id}.
                </span>
                <span className={`${isChecked && option.isCorrect && !isSelected ? "text-green-700 font-medium" : "text-gray-700"}`}>
                  {option.text}
                </span>
              </div>

              {/* Result Feedback Icons */}
              {isChecked && (
                <div className="ml-3">
                  {option.isCorrect && isSelected && (
                    <span className="text-green-600 font-bold flex items-center text-sm">
                      <Check size={18} className="mr-1" /> Đúng
                    </span>
                  )}
                  {!option.isCorrect && isSelected && (
                    <span className="text-red-500 font-bold flex items-center text-sm">
                      <X size={18} className="mr-1" /> Sai
                    </span>
                  )}
                  {option.isCorrect && !isSelected && (
                    <span className="text-green-500 text-sm font-medium px-2 py-1 bg-green-50 rounded">
                      Đáp án đúng
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Actions */}
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end gap-3">
        {isChecked ? (
          <button
            onClick={resetQuestion}
            className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 hover:bg-gray-100 font-medium rounded-lg transition-colors"
          >
            <RefreshCcw size={18} className="mr-2" />
            Làm lại
          </button>
        ) : (
          <button
            onClick={handleCheck}
            disabled={selectedOptions.size === 0}
            className={`
              flex items-center px-6 py-2 rounded-lg font-semibold transition-all shadow-sm
              ${selectedOptions.size === 0 
                ? "bg-gray-200 text-gray-400 cursor-not-allowed" 
                : "bg-blue-600 text-white hover:bg-blue-700 hover:shadow-md hover:-translate-y-0.5"}
            `}
          >
            <Check size={18} className="mr-2" />
            Kiểm tra
          </button>
        )}
      </div>
    </div>
  );
};
