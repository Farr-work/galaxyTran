export interface Option {
  id: string; // "A", "B", "C", "D"
  text: string;
  isCorrect: boolean;
}

export interface Question {
  id: number;
  text: string;
  options: Option[];
}
