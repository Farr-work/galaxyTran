import React, { useState } from 'react';
import { BookOpen, Play, Trash2, FileText } from 'lucide-react';
import { parseQuizContent, SAMPLE_DATA } from './utils/parser';
import { Question } from './types';
import { QuestionCard } from './components/QuestionCard';

const App: React.FC = () => {
  const [inputText, setInputText] = useState<string>("");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [view, setView] = useState<'input' | 'quiz'>('input');

  const handleGenerate = () => {
    const parsed = parseQuizContent(inputText);
    if (parsed.length > 0) {
      setQuestions(parsed);
      setView('quiz');
    } else {
      alert("Không tìm thấy câu hỏi nào hợp lệ. Vui lòng kiểm tra định dạng.");
    }
  };

  const loadSample = () => {
    setInputText(SAMPLE_DATA);
  };

  const handleReset = () => {
    setQuestions([]);
    setView('input');
    setInputText("");
  };

  const handleBackToEdit = () => {
    setView('input');
  };

  return (
    <div className="min-h-screen pb-12">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-blue-600">
            <BookOpen className="w-6 h-6" />
            <h1 className="text-xl font-bold tracking-tight text-gray-900">Quiz Master</h1>
          </div>
          {view === 'quiz' && (
             <div className="flex gap-2">
                <button 
                  onClick={handleBackToEdit}
                  className="text-sm font-medium text-gray-600 hover:text-blue-600 px-3 py-1.5 rounded-md hover:bg-gray-100 transition-colors"
                >
                  Sửa nội dung
                </button>
                <button 
                  onClick={handleReset}
                  className="text-sm font-medium text-red-600 hover:text-red-700 px-3 py-1.5 rounded-md hover:bg-red-50 transition-colors flex items-center gap-1"
                >
                  <Trash2 size={16} />
                  Tạo mới
                </button>
             </div>
          )}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 mt-8">
        {view === 'input' ? (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Nhập dữ liệu câu hỏi</h2>
                  <p className="text-gray-500">
                    Dán câu hỏi của bạn vào bên dưới. Đánh dấu <span className="font-mono font-bold text-blue-600 bg-blue-50 px-1 rounded">*</span> trước đáp án đúng.
                  </p>
                </div>
                <button
                  onClick={loadSample}
                  className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700 font-medium px-4 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
                >
                  <FileText size={16} />
                  Dữ liệu mẫu
                </button>
              </div>

              <div className="relative">
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={`Ví dụ:\nCâu 1: Thủ đô của Việt Nam là gì?\nA. Hồ Chí Minh\n*B. Hà Nội\nC. Đà Nẵng\nD. Cần Thơ`}
                  className="w-full h-[400px] p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-y font-mono text-sm text-gray-800 leading-relaxed"
                />
                <div className="absolute bottom-4 right-4 text-xs text-gray-400 pointer-events-none bg-white/80 px-2 py-1 rounded backdrop-blur-sm">
                  Hỗ trợ Markdown đơn giản
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleGenerate}
                  disabled={!inputText.trim()}
                  className={`
                    flex items-center gap-2 px-8 py-3 rounded-xl font-semibold text-white shadow-lg shadow-blue-200
                    transition-all transform hover:-translate-y-0.5 active:translate-y-0
                    ${!inputText.trim() ? 'bg-gray-300 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 hover:shadow-blue-300'}
                  `}
                >
                  <Play size={20} fill="currentColor" />
                  Tạo Đề Thi
                </button>
              </div>
            </div>

            {/* Guide Section */}
            <div className="mt-8 grid md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold mb-3">1</div>
                <h3 className="font-semibold text-gray-900 mb-2">Chuẩn bị câu hỏi</h3>
                <p className="text-sm text-gray-600">Soạn thảo câu hỏi ra Notepad hoặc Word theo định dạng từng câu.</p>
              </div>
              <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold mb-3">2</div>
                <h3 className="font-semibold text-gray-900 mb-2">Đánh dấu đáp án</h3>
                <p className="text-sm text-gray-600">Thêm dấu sao (*) vào ngay trước chữ cái của đáp án đúng (VD: *A. Nội dung).</p>
              </div>
              <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold mb-3">3</div>
                <h3 className="font-semibold text-gray-900 mb-2">Tạo & Ôn tập</h3>
                <p className="text-sm text-gray-600">Nhấn nút Tạo Đề Thi và bắt đầu ôn tập với chế độ kiểm tra tức thì.</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-500">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Đề ôn tập ({questions.length} câu)</h2>
            </div>
            
            <div className="space-y-8">
              {questions.map((q) => (
                <QuestionCard key={q.id} question={q} />
              ))}
            </div>
            
            <div className="mt-12 p-8 text-center bg-white rounded-xl border border-gray-200 shadow-sm">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Đã hết câu hỏi</h3>
              <p className="text-gray-500 mb-6">Bạn có muốn ôn tập lại bộ câu hỏi này không?</p>
              <button 
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="px-6 py-2 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors"
              >
                Cuộn lên đầu trang
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
